/* Make PHP MongoDB use PHP streams */
#define MONGO_PHP_STREAMS 1
/* FIXME: How to add build dependencies on windows? */
#define HAVE_MONGO_SASL 0
