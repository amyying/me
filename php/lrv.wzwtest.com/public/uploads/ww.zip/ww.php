<?php
$a = 'dsfgds,efwi7eurif';
$b = 'dfwori.weryowef,wryuwiue324';
echo similar_text($a, $b, $p);
echo "---{$p}".PHP_EOL;

echo levenshtein($a, $b);

// echo get_img_save_path('sku_25561_1_small.jpg', '/var/');

 // function get_img_save_path($img_name, $prefix_path) {
 //        $pattern = "/\\d+/";
 //        preg_match_all($pattern, $img_name, $matchs);
 //        if (!empty($matchs)) {
 //            $sku_img_name = substr(strrev($matchs[0][0]), 0, 3);
 //            if (strlen($sku_img_name) < 3) { // match dx.com image file store rule;
 //                return FALSE;
 //            }
 //            $p = $prefix_path . $sku_img_name[0] . '/' . $sku_img_name[1] . '/' . $sku_img_name[2] . '/';
 //            return $p;
 //        }
 //        return false;
 //    }

    preg_match("/(items)\s+(\d{1,})-(\d{1,})\/(\d{1,})/", "items 0-2/3", $matches);
 // var_dump($matches);
 $a = array(
    'a'=>array('ii'=>'dfd'),
    'b'=>array('c'=>array('d'=>'ddcd')));
 print_r(array_keys($a));
 echo md5(date('Y-m-d') . 'dxlisting');
 echo json_encode(array('333'));echo json_encode(array(333));
?>